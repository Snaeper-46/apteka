package com.example.apteka;

import java.io.Serializable;

public class MedsItem implements Serializable {
    private String name;
    private String manufacturer;
    private double price;
    private String date;
    private String form;
    private int amount;
    private int image;

    public MedsItem(String name, double price, int image, String manufacturer, String date, String form, int amount){
        this.name = name;
        this.manufacturer = manufacturer;
        this.price = price;
        this.date = date;
        this.form = form;
        this.amount = amount;
        this.image = image;
    }
    public String getName(){
        return name;
    }
    public String getManufacturer(){return manufacturer;}
    public double getPrice(){
        return price;
    }

    public String getDate() {return date;}

    public String getForm() {return form;}
    public int getAmount() {return amount;}
    public int getImage(){
        return image;
    }
}
