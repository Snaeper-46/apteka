package com.example.apteka;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class CategoriesActivity extends AppCompatActivity {

    private ArrayList<CategoriesItem> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);
        initCategories();
        //адаптер для категорий
        CtgrAdapter adapter = new CtgrAdapter(this, list);
        ListView listMeds= findViewById(R.id.categories_list);

        listMeds.setAdapter(adapter);
        listMeds.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id){
                CategoriesItem item = (CategoriesItem) adapter.getItem(pos);
                CategoriesItem contact = new CategoriesItem(item.getId(), item.getName(), item.getAbout(), item.getImage());
                Intent intent = new Intent(getApplicationContext(), meds_in_categories.class);
                intent.putExtra(CategoriesItem.class.getSimpleName(), contact);
                startActivity(intent);
            }});
    }

    private void initCategories(){
        list = new ArrayList<CategoriesItem>();
        list.add(new CategoriesItem(1, "Категория 1", "хз", R.drawable.pill));
        list.add(new CategoriesItem(2, "Категория 2", "хз", R.drawable.pill));
        list.add(new CategoriesItem(3, "Категория 3", "хз", R.drawable.pill));
        list.add(new CategoriesItem(4, "Категория 4", "хз", R.drawable.pill));
    }

    public void onCartClick(View v){
        Intent intent = new Intent(this, CartActivity.class);
        startActivity(intent);
        finish();
    }
    public void onHomeClick(View v){
        Intent intent = new Intent(this, mainPage.class);
        startActivity(intent);
        finish();
    }
    public void onFavClick(View v){
    }
    public void onProfileClick(View v){
    }
}