package com.example.apteka;

import java.io.Serializable;

public class CategoriesItem implements Serializable {
    private int id;
    private String name;
    private String about;
    private int image;

    public CategoriesItem(int id, String name, String about, int image) {
        this.id = id;
        this.name = name;
        this.about = about;
        this.image = image;
    }
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public String getAbout() {
        return about;
    }
    public int getImage() {
        return image;
    }
}
