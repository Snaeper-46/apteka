package com.example.apteka;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        ImageView image = findViewById(R.id.image);
        TextView name = findViewById(R.id.textName);
        TextView price = findViewById(R.id.textPrice);
        TextView form = findViewById(R.id.textForm);
        TextView date = findViewById(R.id.textDate);
        TextView manufacturer = findViewById(R.id.textManufacturer);

        Bundle args = getIntent().getExtras();
        if(args!=null){
            MedsItem contact = (MedsItem)args.getSerializable(MedsItem.class.getSimpleName());

            image.setImageResource(contact.getImage());
            name.setText(contact.getName());
            price.setText(String.valueOf(contact.getPrice()) + " ₽");
            form.setText("Форма выпуска: \t"+contact.getForm());
            date.setText("Срок годности: \t"+contact.getDate() + " г.");
            manufacturer.setText("Производитель: \t"+contact.getManufacturer());
        }
    }
    public void onCartClick(View v){
        Intent intent = new Intent(this, CartActivity.class);
        startActivity(intent);
        finish();
    }
    public void onHomeClick(View v){
        Intent intent = new Intent(this, mainPage.class);
        startActivity(intent);
        finish();
    }
    public void onFavClick(View v){
    }
    public void onProfileClick(View v){
    }
}