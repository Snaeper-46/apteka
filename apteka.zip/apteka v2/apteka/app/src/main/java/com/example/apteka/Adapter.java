package com.example.apteka;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Adapter extends BaseAdapter {
    private ArrayList<MedsItem> data;
    private LayoutInflater inflater;

    public Adapter(Context context, ArrayList<MedsItem> data){
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.data = data;
    }
    @Override
    public int getCount(){
        return data.size();
    }
    @Override
    public Object getItem(int position){
        return data.get(position);
    }
    @Override
    public long getItemId(int i){
        return 0;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View view = convertView;
        if(convertView == null) view = inflater.inflate(R.layout.row, null);
        ImageView image = (ImageView)view.findViewById(R.id.image);
        TextView name = (TextView)view.findViewById(R.id.name);
        TextView price = (TextView)view.findViewById(R.id.price);
        MedsItem item = data.get(position);
        image.setImageResource(item.getImage());
        name.setText(item.getName());
        price.setText(String.valueOf(item.getPrice())+" ₽");
        return view;
    }
}
