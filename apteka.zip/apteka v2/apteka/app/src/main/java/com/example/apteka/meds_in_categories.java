package com.example.apteka;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class meds_in_categories extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meds_in_categories);
        TextView title = findViewById(R.id.title);

        //туд заполнение листа хз

        Bundle args = getIntent().getExtras();
        if(args!=null){
            CategoriesItem contact = (CategoriesItem) args.getSerializable(CategoriesItem.class.getSimpleName());

            title.setText(contact.getName());
        }
    }
    public void onCartClick(View v){
        Intent intent = new Intent(this, CartActivity.class);
        startActivity(intent);
        finish();
    }
    public void onHomeClick(View v){
        Intent intent = new Intent(this, mainPage.class);
        startActivity(intent);
        finish();
    }
    public void onFavClick(View v){
    }
    public void onProfileClick(View v){
    }
}