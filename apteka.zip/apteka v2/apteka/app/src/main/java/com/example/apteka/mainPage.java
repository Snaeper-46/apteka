package com.example.apteka;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class mainPage extends AppCompatActivity {


    private ArrayList<MedsItem> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        initContacts();
        //адаптер для таблеток
        Adapter adapter = new Adapter(this, list);
        ListView listMeds= findViewById(R.id.medicines_list);

        listMeds.setAdapter(adapter);
        listMeds.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id){
                MedsItem item = (MedsItem) adapter.getItem(pos);
                MedsItem meds = new MedsItem(item.getName(), item.getPrice(), item.getImage(), item.getManufacturer(), item.getDate(), item.getForm(), item.getAmount());
                Intent intent = new Intent(getApplicationContext(), DetailsActivity.class);
                intent.putExtra(MedsItem.class.getSimpleName(), meds);
                startActivity(intent);
            }});
    }

    private void initContacts(){
        list = new ArrayList<MedsItem>();
        list.add(new MedsItem("бубубуббу", 10, R.drawable.pill, "ЗАВОД", "3", "таблетки", 1000));
        list.add(new MedsItem("бубубуббу", 10, R.drawable.pill, "ЗАВОД", "3", "таблетки", 1000));
        list.add(new MedsItem("бубубуббу", 10, R.drawable.pill, "ЗАВОД", "3", "таблетки", 1000));
        list.add(new MedsItem("бубубуббу", 10, R.drawable.pill, "ЗАВОД", "3", "таблетки", 1000));
        list.add(new MedsItem("бубубуббу", 10, R.drawable.pill, "ЗАВОД", "3", "таблетки", 1000));
        list.add(new MedsItem("бубубуббу", 10, R.drawable.pill, "ЗАВОД", "3", "таблетки", 1000));
        list.add(new MedsItem("бубубуббу", 10, R.drawable.pill, "ЗАВОД", "3", "таблетки", 1000));
        list.add(new MedsItem("эээ", 1000.00, R.drawable.cannabis, "ООО \"Домик в деревне\"", "100", "Целебные травы", 1000));
    }

    public void onCartClick(View v){
        Intent intent = new Intent(this, CartActivity.class);
        startActivity(intent);
    }
    public void onHomeClick(View v){
        Intent intent = new Intent(this, mainPage.class);
        startActivity(intent);
        finish();
    }
    public void onFavClick(View v){
    }
    public void onProfileClick(View v){
    }
    public void onCategoriesClick(View v){
        Intent intent = new Intent(this, CategoriesActivity.class);
        startActivity(intent);
    }

}